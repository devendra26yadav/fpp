package Assignments.Assignment6.Lesson8.prob2;

public interface EmployeeData {
    public double getSalary();
}
